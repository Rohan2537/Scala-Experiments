/**
  * Created by rohabhos on 20-03-2019.
  */

object TuplesDemo extends App{
  val tuple = (1,2,"Scala","Spark")
  println(tuple)
  println(tuple._1)
  println(tuple._1 + tuple._2)
  println(tuple._3)
  println(tuple._4)
}