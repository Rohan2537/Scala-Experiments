/**
  * Created by rohabhos on 22-03-2019.
  */
import scala.io._
import spray.json._
import scala.util.parsing.json._
import java.io.StringWriter
import au.com.bytecode.opencsv.CSVWriter
import scala.collection.JavaConversions._
import java.io.FileWriter
import java.io.BufferedWriter

object IODemo extends App{
  val jsonString = Source.fromFile("C:/Users/rohabhos/Desktop/Scala/Scala exercise/reserved.json").mkString

  val value1 = """{ "foo": "bar" }"""
  val parsed = JSON.parseFull(value1)
  println(parsed.getOrElse("foo"))

  val value2 = """{ "foo": "bar" }""".parseJson  // JsValue = {"foo":"bar"}
  println(value2)
 // value2.convertTo[Map[String, String]]

 /* val out = new BufferedWriter(new FileWriter("C:/Users/rohabhos/Desktop/Scala/Scala exercise/reservation.csv"));
  val writer = new CSVWriter(out);
  val reservationSchema=Array("Name","Platform","Current_Reservation","Required_Reservation","Instance_id")

  val employee1= Array("Rohan","23","computerscience","NA","NA")

  println(jsonString.contains("Tags"))

  var listOfRecords= List(reservationSchema,employee1)

  writer.writeAll(listOfRecords)

  out.close()*/
  case class Tags(
                   Value: String,
                   Key: String
                 )
}
