/**
  * Created by rohabhos on 26-03-2019.
  */
package XmlParsing

import java.io.{FileWriter, BufferedWriter}

import au.com.bytecode.opencsv.CSVWriter

import scala.xml.XML
import java.io.File

object XmlParsingDemo extends App {

  val dir = new File("C:/Users/rohabhos/Desktop/Scala/Scala exercise/1.43TTF")

  def getRecursiveListOfFiles(dir: File): Array[File] = {
    val these = dir.listFiles
    these ++ these.filter(_.isDirectory).flatMap(getRecursiveListOfFiles)
  }

  val listOfFileNames =  getRecursiveListOfFiles(dir)
  val fileName = listOfFileNames(0).getName
  val values = fileName.split("_")
  val  effectiveTension = values(1)+"_"+ values(2) +"_" +  values(3)
  /*val ttf = values(1).replace("TTF","")
  val tilt = values(3).replace("T","")
  val direction = values(2).replace("d","")*/

  val xmlData = XML.loadFile(listOfFileNames(0))
  //println("aa "+xmlData \\ "Plot2" \\"Set" \\ "PlotPoint" \\"@X")
  val x = xmlData \\ "Plot2" \\"Set" \\ "PlotPoint" \\"@X"
  val length = x.toList
  val element = xmlData \\ "Plot2" \\"Set" \\ "PlotPoint" \\"@Tool"
  // println(element.toList) //toString().split(":").toString)
  val b = element.flatMap(e => e.toString().split(";"))
  println(x)
  println(b)
  // println("bb "+xmlData \\ "Plot2" \\"Set" \\ "PlotPoint" \\"@Tool")

  val out = new BufferedWriter(new FileWriter("C:/Users/rohabhos/Desktop/Scala/Scala exercise/xmlTOcsv.csv"));
  val writer = new CSVWriter(out);
}
